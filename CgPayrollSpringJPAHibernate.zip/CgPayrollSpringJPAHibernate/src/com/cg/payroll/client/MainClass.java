package com.cg.payroll.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	
	public static void main(String[] args) throws PayrollServicesDownException,AssociateDetailsNotFoundException{
		
		ApplicationContext context=new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices=(PayrollServices) context.getBean("payrollServices");
	
	int associateID=payrollServices.acceptAssociateDetails("keshav", "agarwal", "keshav@gmail.com", "YTP", "Sr.analyst", "GSHDA23F", 20000, 17300, 2000, 2000, 5336355, "HDFC", "HDFC0000007");
	System.out.println(associateID);
	//int associateID1=payrollservices.acceptAssociateDetails("anayatullah", "rafe", "rafe@gmail.com", "YTP", "Sr.analyst", "GSHDA23F", 10000, 7300, 1000, 1000, 4336355, "HDFC", "HDFC0000007");
	//System.out.println(associateID);
	//payrollservices.calculateNetSalary(associateID);
	//payrollservices.calculateNetSalary(associateID1);
	
	System.out.println( payrollServices.getAssociateDetails(associateID));
	
	/*ArrayList<Associate> associateList=payrollservices.getAllAssociatesDetails();
	for (Associate associate2 : associateList) 
		System.out.println(associate2.toString());*/
	
	/*System.out.println(payrollservices.getAllAssociatesDetails());*/

}
}
